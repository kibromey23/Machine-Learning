// Core Utility Functions
async function apiFetch(endpoint, options = {}) {
    const fullUrl = `http://localhost:3000/api${endpoint}`;
    console.log(`Fetching: ${fullUrl}`);
    const token = getCookie('authToken');
    try {
        const response = await fetch(fullUrl, {
            ...options,
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json',
                ...(token && { Authorization: `Bearer ${token}` }),
                ...options.headers,
            },
        });
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || `HTTP error! Status: ${response.status}`);
        }
        return await response.json();
    } catch (err) {
        console.error(`Fetch error at ${endpoint}:`, err.message);
        throw err;
    }
}

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    return parts.length === 2 ? parts.pop().split(';').shift() : null;
}

function showMessage(containerId, message, isSuccess = true) {
    const container = document.getElementById(containerId);
    if (!container) return;
    let messageDiv = container.querySelector('.message');
    if (!messageDiv) {
        messageDiv = document.createElement('div');
        messageDiv.className = 'message';
        container.appendChild(messageDiv);
    }
    messageDiv.textContent = message;
    messageDiv.className = `message ${isSuccess ? 'text-green-500' : 'text-red-500'}`;
    messageDiv.classList.remove('hidden');
    setTimeout(() => messageDiv.classList.add('hidden'), 3000);
}

function toggleLoading(button, isLoading) {
    if (!button) return;
    button.disabled = isLoading;
    button.textContent = isLoading ? 'Loading...' : (button.dataset.text || button.textContent.trim());
}

// Authentication
async function checkAuth() {
    const token = getCookie('authToken');
    if (!token) return false;
    try {
        const response = await apiFetch('/check-auth');
        return response.success === true;
    } catch (error) {
        console.error('Auth check failed:', error.message);
        return false;
    }
}

async function protectPage() {
    const publicPages = ['/index.html', '/', '/reset-password.html'];
    const currentPath = location.pathname;
    if (publicPages.some(page => currentPath.includes(page))) return true;

    const isAuthenticated = await checkAuth();
    if (!isAuthenticated && !sessionStorage.getItem('redirecting')) {
        sessionStorage.setItem('redirecting', 'true');
        window.location.href = '/index.html';
        return false;
    }
    sessionStorage.removeItem('redirecting');
    return true;
}

// Login
function setupLogin() {
    const loginForm = document.getElementById('loginForm');
    if (!loginForm) return;

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('loginUsername')?.value.trim();
        const password = document.getElementById('loginPassword')?.value;
        const submitBtn = loginForm.querySelector('button[type="submit"]');
        if (!submitBtn) return;

        submitBtn.dataset.text = submitBtn.textContent.trim() || 'Login';

        if (!username || !password || username.length < 6 || password.length < 6) {
            showMessage('loginForm', 'Username and password must be at least 6 characters', false);
            return;
        }

        toggleLoading(submitBtn, true);
        try {
            const result = await apiFetch('/login', {
                method: 'POST',
                body: JSON.stringify({ username, password }),
            });
            toggleLoading(submitBtn, false);
            if (result.success) {
                window.location.href = '/home.html';
            } else {
                showMessage('loginForm', result.message || 'Login failed', false);
            }
        } catch (err) {
            toggleLoading(submitBtn, false);
            showMessage('loginForm', err.message || 'An error occurred during login', false);
        }
    });
}


///////////////////////////
// Add this before the DOMContentLoaded listener (e.g., around line 400)
async function loadPackagesForPurchase() {
    if (!location.pathname.includes('product.html')) return;
    try {
        const result = await apiFetch('/packages');
        console.log('Packages fetched:', result); // Debug API response
        const packageList = document.querySelector('.grid.grid-cols-1');
        if (packageList && result.success) {
            packageList.innerHTML = result.packages.map(pkg => {
                if (!pkg._id || typeof pkg._id !== 'string') {
                    console.error('Invalid package _id:', pkg);
                    return ''; // Skip invalid packages
                }
                return `
                    <div class="package bg-white p-4 rounded shadow flex">
                        <img src="images/${pkg.name.toLowerCase().replace(' ', '-')}.jpg" alt="${pkg.name}" class="w-24 h-24 mr-4">
                        <div>
                            <h2 class="font-bold text-lg">${pkg.name}</h2>
                            <p>Price: ${pkg.price} ETB</p>
                            <p>Daily Income: ${pkg.dailyIncome} ETB</p>
                            <p>Valid for: ${pkg.validityDays} days</p>
                            <button class="buy-btn bg-blue-500 text-white p-2 rounded mt-2 hover:bg-blue-600" data-package-id="${pkg._id}">Buy</button>
                        </div>
                    </div>
                `;
            }).join('');
        } else {
            console.warn('No packages or invalid response:', result);
        }
    } catch (err) {
        console.error('Error loading packages:', err.message);
        // Fallback to static packages if API fails (preserving original behavior)
    }
}

// Main Initialization
document.addEventListener('DOMContentLoaded', async () => {
    setupLogin();
    const isPageAccessible = await protectPage();
    if (!isPageAccessible) return;

    const menuToggle = document.getElementById('menu-toggle');
    const menu = document.getElementById('menu');
    if (menuToggle && menu) {
        menuToggle.addEventListener('click', () => {
            menu.classList.toggle('hidden');
            menu.classList.toggle('active');
        });
    }
    const userIcon = document.getElementById('user-icon');
    const userDropdown = document.getElementById('user-dropdown');
    if (userIcon && userDropdown) {
        userIcon.addEventListener('click', (e) => {
            e.preventDefault();
            userDropdown.classList.toggle('hidden');
        });
        document.addEventListener('click', (e) => {
            if (!userIcon.contains(e.target) && !userDropdown.contains(e.target)) {
                userDropdown.classList.add('hidden');
            }
        });
    }

    const logoutButton = document.getElementById('logout');
    if (logoutButton) {
        logoutButton.addEventListener('click', async (e) => {
            e.preventDefault();
            await apiFetch('/logout', { method: 'POST' });
            document.cookie = 'authToken=; Max-Age=-99999999; path=/';
            sessionStorage.clear();
            window.location.href = '/index.html';
        });
    }

    const currentPath = location.pathname;
    if (currentPath.includes('myprofile.html')) {
        loadProfile();
    } else if (currentPath.includes('product.html')) {
        loadPackagesForPurchase();
    } else if (currentPath.includes('admin.html')) {
        loadAdminDashboard();
        loadPurchaseRequests();
    }

    // Signup
    const signupForm = document.getElementById('signupForm');
    if (signupForm) {
        signupForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = document.getElementById('username')?.value.trim();
            const email = document.getElementById('email')?.value.trim();
            const phone = document.getElementById('phone')?.value.trim();
            const password = document.getElementById('password')?.value;
            const confirmPassword = document.getElementById('confirmPassword')?.value;
            const ref = document.getElementById('ref')?.value.trim() || '';
            const submitBtn = signupForm.querySelector('button[type="submit"]');
            submitBtn.dataset.text = 'Sign Up';

            if (!username || !email || !phone || !password || !confirmPassword) {
                showMessage('signupForm', 'All fields are required', false);
                return;
            }
            if (password !== confirmPassword) {
                showMessage('signupForm', 'Passwords do not match', false);
                return;
            }
            if (username.length < 6 || password.length < 6) {
                showMessage('signupForm', 'Username and password must be at least 6 characters', false);
                return;
            }
            if (!/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email)) {
                showMessage('signupForm', 'Invalid email format', false);
                return;
            }

            toggleLoading(submitBtn, true);
            try {
                const result = await apiFetch('/signup', {
                    method: 'POST',
                    body: JSON.stringify({ username, email, phone, password, ref }),
                });
                toggleLoading(submitBtn, false);
                if (result.success) {
                    showMessage('signupForm', `${result.message} (For testing, use code: 123456)`, true);
                    setTimeout(() => toggleSections('signup', 'login'), 2000);
                } else {
                    showMessage('signupForm', result.message, false);
                }
            } catch (err) {
                toggleLoading(submitBtn, false);
                showMessage('signupForm', err.message || 'Signup failed', false);
            }
        });
    }

    // Toggle Sections
    const showLoginLink = document.getElementById('showLogin');
    const showSignupLink = document.getElementById('showSignup');
    if (showLoginLink) showLoginLink.addEventListener('click', (e) => {
        e.preventDefault();
        toggleSections('signup', 'login');
    });
    if (showSignupLink) showSignupLink.addEventListener('click', (e) => {
        e.preventDefault();
        toggleSections('login', 'signup');
    });

    // Referral Code Pre-fill
    if (currentPath.includes('index.html')) {
        const urlParams = new URLSearchParams(window.location.search);
        const refCode = urlParams.get('ref');
        if (refCode) {
            document.getElementById('ref').value = refCode;
            console.log('Referral code pre-filled:', refCode);
        }
    }

    // Forgot Password
    const forgotPasswordLink = document.getElementById('forgotPassword');
    if (forgotPasswordLink) {
        forgotPasswordLink.addEventListener('click', (e) => {
            e.preventDefault();
            const email = prompt('Enter your email to reset password:');
            if (email) {
                apiFetch('/forgot-password', {
                    method: 'POST',
                    body: JSON.stringify({ email }),
                }).then(result => {
                    showMessage('loginForm', result.message, result.success);
                }).catch(err => {
                    showMessage('loginForm', err.message || 'Error occurred', false);
                });
            }
        });
    }
});

// Profile
async function loadProfile() {
    try {
        const result = await apiFetch('/profile');
        if (result?.success) {
            updateProfileUI(result);
            updateOrdersUI(result);
            // Team and withdrawal history are fetched separately if needed
            document.getElementById('referralLink').value = result.referralLink || 'N/A';
        } else {
            throw new Error(result.message || 'Invalid API response');
        }
    } catch (err) {
        console.error('Error loading profile:', err.message);
        showErrorInUI();
    }
}

function updateProfileUI(data) {
    const setText = (id, value) => {
        const element = document.getElementById(id);
        if (element) element.textContent = value ?? 'N/A';
    };
    setText('userId', data._id);
    setText('userName', data.username);
    setText('todayIncome', data.todayIncome);
    setText('referralIncomeToday', data.referralIncomeToday);
    setText('totalReferralIncome', data.totalReferralIncome);
    setText('totalIncome', data.totalIncome);
    setText('totalWithdraw', data.totalWithdraw);
    setText('currentBalance', data.currentBalance);
}

function updateOrdersUI(data) {
    const orderSection = document.getElementById('orderDetails');
    if (!orderSection) return;
    orderSection.innerHTML = data.package
        ? `
            <div class="order-card">
                <h3>Package: ${data.package.name}</h3>
                <p><strong>Price:</strong> ${data.package.price} ETB</p>
                <p><strong>Daily Income:</strong> ${data.package.dailyIncome} ETB</p>
                <p><strong>Validity:</strong> ${data.package.validityDays} days</p>
                <p><strong>Status:</strong> Activated ✅</p>
            </div>
        `
        : '<p>No active packages found.</p>';
}

function showErrorInUI() {
    ['userId', 'userName', 'todayIncome', 'referralIncomeToday', 'totalReferralIncome', 'totalIncome', 'totalWithdraw', 'currentBalance']
        .forEach(id => {
            const element = document.getElementById(id);
            if (element) element.textContent = 'Error';
        });
}

// Team
document.addEventListener('DOMContentLoaded', () => {
    const copyReferralLinkBtn = document.getElementById('copyReferralLink');
    if (copyReferralLinkBtn) {
        copyReferralLinkBtn.addEventListener('click', () => {
            const referralLink = document.getElementById('referralLink');
            referralLink.select();
            document.execCommand('copy');
            showMessage('team', 'Referral link copied to clipboard!', true);
        });
    }
});

// Withdrawals
document.addEventListener('DOMContentLoaded', () => {
    const withdrawForm = document.getElementById('withdrawForm');
    if (withdrawForm) {
        withdrawForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const amount = document.getElementById('withdrawAmount')?.value;
            const method = document.getElementById('withdrawMethod')?.value;
            const withdrawPassword = document.getElementById('withdrawPasswordWithdraw')?.value;
            const submitBtn = withdrawForm.querySelector('button[type="submit"]');
            toggleLoading(submitBtn, true);
            try {
                const result = await apiFetch('/request-withdrawal', {
                    method: 'POST',
                    body: JSON.stringify({ amount, method, withdrawPassword }),
                });
                toggleLoading(submitBtn, false);
                showMessage('withdrawForm', result.message || 'Withdrawal request sent to admin!', result.success);
            } catch (err) {
                toggleLoading(submitBtn, false);
                showMessage('withdrawForm', err.message || 'Withdrawal request failed', false);
            }
        });
    }

    const bankForm = document.getElementById('bankForm');
    if (bankForm) {
        bankForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const bankAccount = document.getElementById('bankAccount')?.value;
            const [bankName, accountNumber] = bankAccount.split(' - ');
            const submitBtn = bankForm.querySelector('button[type="submit"]');
            toggleLoading(submitBtn, true);
            try {
                const result = await apiFetch('/bank', {
                    method: 'POST',
                    body: JSON.stringify({ bankName, accountNumber }),
                });
                toggleLoading(submitBtn, false);
                showMessage('bankForm', result.message, result.success);
            } catch (err) {
                toggleLoading(submitBtn, false);
                showMessage('bankForm', err.message || 'Update failed', false);
            }
        });
    }

    const withdrawPasswordForm = document.getElementById('withdrawPasswordForm');
    if (withdrawPasswordForm) {
        withdrawPasswordForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const withdrawPassword = document.getElementById('withdrawPasswordSet')?.value;
            const confirmWithdrawPassword = document.getElementById('confirmWithdrawPassword')?.value;
            const submitBtn = withdrawPasswordForm.querySelector('button[type="submit"]');
            if (withdrawPassword !== confirmWithdrawPassword) {
                showMessage('withdrawPasswordForm', 'Passwords do not match', false);
                return;
            }
            toggleLoading(submitBtn, true);
            try {
                const result = await apiFetch('/withdraw-password', {
                    method: 'POST',
                    body: JSON.stringify({ withdrawPassword }),
                });
                toggleLoading(submitBtn, false);
                showMessage('withdrawPasswordForm', result.message, result.success);
            } catch (err) {
                toggleLoading(submitBtn, false);
                showMessage('withdrawPasswordForm', err.message || 'Password set failed', false);
            }
        });
    }
});

// Password
document.addEventListener('DOMContentLoaded', () => {
    const changePasswordForm = document.getElementById('changePasswordForm');
    if (changePasswordForm) {
        changePasswordForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const oldPassword = document.getElementById('oldPassword')?.value;
            const newPassword = document.getElementById('newPassword')?.value;
            const confirmNewPassword = document.getElementById('confirmNewPassword')?.value;
            const submitBtn = changePasswordForm.querySelector('button[type="submit"]');
            toggleLoading(submitBtn, true);
            try {
                const result = await apiFetch('/change-password', {
                    method: 'POST',
                    body: JSON.stringify({ oldPassword, newPassword, confirmNewPassword }),
                });
                toggleLoading(submitBtn, false);
                showMessage('changePasswordForm', result.message, result.success);
            } catch (err) {
                toggleLoading(submitBtn, false);
                showMessage('changePasswordForm', err.message || 'Password change failed', false);
            }
        });
    }
});

// Sidebar Navigation
document.addEventListener('DOMContentLoaded', () => {
    const sidebarLinks = document.querySelectorAll('.sidebar a:not(#logout)');
    if (sidebarLinks.length > 0) {
        sidebarLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.getAttribute('data-section');
                document.querySelectorAll('.account-section').forEach(s => s.classList.add('hidden'));
                document.getElementById(section).classList.remove('hidden');
            });
        });
    }
});

// Product
async function loadPackages() {
    const result = await apiFetch('/admin/package-requests');
    if (result.success) {
        document.getElementById('purchaseRequestList').innerHTML = result.requests.map(req => `
            <tr>
                <td>${req.userId.username}</td>
                <td>${req.packageId.name}</td>
                <td>${req.paymentMethod}</td>
                <td>${req.status}</td>
                <td>
                    <button onclick="managePurchase('${req._id}', 'approve')" class="bg-green-500 text-white p-2 rounded">Approve</button>
                    <button onclick="managePurchase('${req._id}', 'reject')" class="bg-red-500 text-white p-2 rounded">Reject</button>
                </td>
            </tr>
        `).join('');
    }
}
///////////////////////////////////////////

let selectedPackageId = null;
document.addEventListener('DOMContentLoaded', () => {
    loadPackagesForPurchase();
    document.querySelectorAll('.buy-btn').forEach(button => {
        button.addEventListener('click', () => {
            selectedPackageId = button.dataset.packageId;
            console.log('Selected packageId on click:', selectedPackageId); // Debug selection
            document.getElementById('paymentModal')?.classList.remove('hidden');
        });
    });

    const paymentForm = document.getElementById('paymentForm'); // Define paymentForm here
    if (paymentForm) { // Ensure it exists
        paymentForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const paymentMethod = document.getElementById('paymentMethod')?.value;
            const submitBtn = paymentForm.querySelector('button[type="submit"]');
            if (!selectedPackageId || !paymentMethod) {
                showMessage('paymentForm', 'Please select a package and payment method', false);
                return;
            }
            // Validate packageId format
            if (!/^[0-9a-fA-F]{24}$/.test(selectedPackageId)) {
                showMessage('paymentForm', 'Invalid package selection. Please try again.', false);
                console.error('Invalid packageId format:', selectedPackageId);
                return;
            }
            toggleLoading(submitBtn, true);
            try {
                const directPurchase = confirm('Purchase directly without admin approval? (Yes for direct, No for request)');
                const endpoint = directPurchase ? '/purchase-package' : '/request-purchase';
                console.log('Sending request to:', endpoint, { packageId: selectedPackageId, paymentMethod }); // Debug payload
                const result = await apiFetch(endpoint, {
                    method: 'POST',
                    body: JSON.stringify({ packageId: selectedPackageId, paymentMethod }),
                });
                toggleLoading(submitBtn, false);
                showMessage('paymentForm', directPurchase ? 'Package purchased!' : 'Purchase request sent to admin!', true);
                setTimeout(() => document.getElementById('paymentModal')?.classList.add('hidden'), 2000);
            } catch (err) {
                toggleLoading(submitBtn, false);
                console.error('Purchase request failed:', err.message);
                showMessage('paymentForm', err.message || 'Purchase failed', false);
            }
        });
    }

    document.getElementById('closeModal')?.addEventListener('click', () => {
        document.getElementById('paymentModal')?.classList.add('hidden');
        selectedPackageId = null;
    });
});
    ////////////////

    paymentForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const paymentMethod = document.getElementById('paymentMethod')?.value;
        const submitBtn = paymentForm.querySelector('button[type="submit"]');
        if (!selectedPackageId || !paymentMethod) {
            showMessage('paymentForm', 'Please select a payment method', false);
            return;
        }
        toggleLoading(submitBtn, true);
        try {
            const directPurchase = confirm('Purchase directly without admin approval? (Yes for direct, No for request)');
            const endpoint = directPurchase ? '/purchase-package' : '/request-purchase';
            const result = await apiFetch(endpoint, {
                method: 'POST',
                body: JSON.stringify({ packageId: selectedPackageId, paymentMethod }),
            });
            toggleLoading(submitBtn, false);
            showMessage('paymentForm', directPurchase ? 'Package purchased!' : 'Purchase request sent to admin!', true);
            setTimeout(() => document.getElementById('paymentModal')?.classList.add('hidden'), 2000);
        } catch (err) {
            toggleLoading(submitBtn, false);
            showMessage('paymentForm', err.message || 'Purchase failed', false);
        }
    });
    ///////////////////////////

    document.getElementById('closeModal')?.addEventListener('click', () => {
        document.getElementById('paymentModal')?.classList.add('hidden');
        selectedPackageId = null;
    });

// Admin
async function loadAdminDashboard() {
    if (!location.pathname.includes('admin.html')) return;
    const sections = document.querySelectorAll('.section');
    const navLinks = document.querySelectorAll('.sidebar a[data-section]');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const section = link.getAttribute('data-section');
            sections.forEach(s => s.classList.add('hidden'));
            document.getElementById(section).classList.remove('hidden');
            if (section === 'overview') loadAdminOverview();
            else if (section === 'users') loadUsers();
            else if (section === 'referrals') loadReferrals();
            else if (section === 'packages') loadPackages();
            else if (section === 'transactions') loadTransactions();
        });
    });
    loadAdminOverview();
}

async function loadAdminOverview() {
    const result = await apiFetch('/admin/overview');
    if (result.success) {
        document.getElementById('totalUsers').textContent = result.overview.totalUsers;
        document.getElementById('activeUsers').textContent = result.overview.activeUsers;
        document.getElementById('totalSales').textContent = `${result.overview.totalSales} ETB`;
        document.getElementById('totalWithdrawals').textContent = `${result.overview.totalWithdrawals} ETB`;
        document.getElementById('totalReferralCommissions').textContent = `${result.overview.totalReferralCommissions} ETB`;
        document.getElementById('pendingApprovals').textContent = result.overview.pendingApprovals;
    }
}

async function loadUsers(page = 1) {
    const search = document.getElementById('userSearch').value;
    const result = await apiFetch(`/admin/users?search=${search}&page=${page}&limit=10`);
    const userList = document.getElementById('userList');
    userList.innerHTML = result.users.map(user => `
        <tr>
            <td>${user.username}</td>
            <td>${user.email}</td>
            <td>${user.active === 1 ? 'Yes' : 'No'}</td>
            <td>
                <button onclick="toggleUserActive('${user._id}')" class="bg-${user.active === 1 ? 'red' : 'green'}-500 text-white p-1 rounded">${user.active === 1 ? 'Deactivate' : 'Activate'}</button>
                <button onclick="viewUserDetails('${user._id}')" class="bg-blue-500 text-white p-1 rounded">View</button>
            </td>
        </tr>
    `).join('');
    document.getElementById('userPagination') && (document.getElementById('userPagination').innerHTML = Array.from({ length: result.pages }, (_, i) => `
        <button onclick="loadUsers(${i + 1})" class="p-2 ${i + 1 === page ? 'bg-blue-500 text-white' : 'bg-gray-200'} rounded">${i + 1}</button>
    `).join(''));
    document.getElementById('userSearch').addEventListener('input', () => loadUsers());
}

window.toggleUserActive = async (userId) => {
    await apiFetch('/admin/user/toggle-active', { method: 'POST', body: JSON.stringify({ userId }) });
    loadUsers();
};

window.viewUserDetails = async (userId) => {
    const result = await apiFetch(`/admin/user/${userId}`);
    document.getElementById('userDetails') && (document.getElementById('userDetails').innerHTML = `
        <p><strong>Username:</strong> ${result.user.username}</p>
        <p><strong>Email:</strong> ${result.user.email}</p>
        <p><strong>Package:</strong> ${result.user.package?.name || 'None'}</p>
        <p><strong>Referrals:</strong> ${result.referrals.length}</p>
        <p><strong>Payments:</strong> ${result.payments.map(p => `${p.amount} ETB (${p.method})`).join(', ')}</p>
    `);
    document.getElementById('userDetails')?.classList.remove('hidden');
};

async function loadReferrals() {
    const result = await apiFetch('/admin/referrals');
    document.getElementById('totalReferrals').textContent = result.totalReferrals;
    document.getElementById('levelAReferrals').textContent = result.levelA;
}

async function loadPackages() {
    const requests = await apiFetch('/admin/purchase-requests');
    document.getElementById('purchaseRequestList').innerHTML = requests.requests.map(req => `
        <tr>
            <td>${req.userId.username}</td>
            <td>${req.packageId.name}</td>
            <td>${req.paymentMethod}</td>
            <td>${req.status}</td>
            <td>
                <button onclick="managePurchase('${req._id}', 'approve')" class="bg-green-500 text-white p-2 rounded">Approve</button>
                <button onclick="managePurchase('${req._id}', 'reject')" class="bg-red-500 text-white p-2 rounded">Reject</button>
            </td>
        </tr>
    `).join('');
}

window.managePurchase = async (requestId, action) => {
    await apiFetch('/admin/manage-purchase', { method: 'POST', body: JSON.stringify({ requestId, action }) });
    loadPackages();
    if (action === 'approve') notifyUserApproval();
};

async function notifyUserApproval() {
    await loadProfile();
    alert('Your package has been approved and is now active!');
}

async function loadTransactions() {
    const result = await apiFetch('/admin/transactions');
    document.getElementById('depositList').innerHTML = result.deposits.map(d => `
        <tr><td>${d.userId}</td><td>${d.amount} ETB</td><td>${d.method}</td><td>${d.date}</td></tr>
    `).join('');
    document.getElementById('withdrawalList').innerHTML = result.withdrawals.map(w => `
        <tr><td>${w.username}</td><td>${w.totalWithdraw} ETB</td></tr>
    `).join('');

    const withdrawalRequests = await apiFetch('/admin/withdrawal-requests');
    document.getElementById('withdrawalRequestList').innerHTML = withdrawalRequests.requests.map(req => `
        <tr>
            <td>${req.userId.username}</td>
            <td>${req.amount} ETB</td>
            <td>${req.method}</td>
            <td>${req.status}</td>
            <td>
                <button onclick="manageWithdrawal('${req._id}', 'approve')" class="bg-green-500 text-white p-2 rounded">Approve</button>
                <button onclick="manageWithdrawal('${req._id}', 'reject')" class="bg-red-500 text-white p-2 rounded">Reject</button>
            </td>
        </tr>
    `).join('');
}

window.manageWithdrawal = async (requestId, action) => {
    await apiFetch('/admin/manage-withdrawal', { method: 'POST', body: JSON.stringify({ requestId, action }) });
    loadTransactions();
};

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('sendGiftForm')?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('giftUsername').value;
        const giftCode = document.getElementById('giftCode').value;
        const result = await apiFetch('/admin/send-gift', { method: 'POST', body: JSON.stringify({ username, giftCode }) });
        showMessage('gifts', result.message, result.success);
    });
});

// Utility
function toggleSections(hideId, showId) {
    document.getElementById(hideId)?.classList.add('hidden');
    document.getElementById(showId)?.classList.remove('hidden');
}