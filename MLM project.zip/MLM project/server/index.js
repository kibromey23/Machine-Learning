/*
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const apiRoutes = require('./routes/api');
const path = require('path');

const PORT = process.env.PORT || 3000;
const app = express();

// Middleware
app.use(express.json());
app.use(cookieParser());
app.use(cors({
    origin: 'http://localhost:3000', // Match frontend port
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Static file serving
app.use('/static', express.static(path.join(__dirname, '../clients')));
// Serve frontend at root
app.use('/', express.static(path.join(__dirname, '../clients')));
// API routes (takes precedence over static /admin)
app.use('/api', apiRoutes);

// MongoDB Connection
mongoose.set('strictQuery', true);
mongoose.connect('mongodb://localhost:27017/mlm_system', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error('MongoDB connection error:', err));

// Start Server
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

*/
////////////////////////////////////////

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const apiRoutes = require('./routes/api');
const path = require('path');

const PORT = process.env.PORT || 3000;
const app = express();

// Middleware
app.use(express.json());
app.use(cookieParser());
app.use(cors({
    origin: (origin, callback) => {
        const allowedOrigins = ['http://localhost:3000', 'http://localhost:8080'];
        if (!origin || allowedOrigins.includes(origin)) {
            callback(null, true);
        } else {
            callback(new Error('Not allowed by CORS'));
        }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Log all requests
app.use((req, res, next) => {
    console.log(`Request: ${req.method} ${req.url}`);
    next();
});

// Static file serving
app.use('/static', express.static(path.join(__dirname, '../clients')));
//app.use('/', express.static(path.join(__dirname, '../clients')));
app.use('/admin', express.static(path.join(__dirname, 'views'), {
    setHeaders: (res, path) => {
        console.log(`Serving static file: ${path}`);
    }
}));

app.use('/', express.static(path.join(__dirname, '../clients'), {
    setHeaders: (res, path) => {
        console.log(`Serving client file: ${path}`);
    }
}));

// API routes
app.use('/api', apiRoutes);

// MongoDB Connection
mongoose.set('strictQuery', true);
mongoose.connect('mongodb://localhost:27017/mlm_system', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error('MongoDB connection error:', err));

// Start Server
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
