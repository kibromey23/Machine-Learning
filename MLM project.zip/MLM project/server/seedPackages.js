const mongoose = require('mongoose');
const Package = require('./models/Package');

mongoose.connect('mongodb://localhost:27017/mlm_system', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error('MongoDB connection error:', err));

const packages = [
    {
        name: 'silver-starter',
        price: 1500,
        dailyIncome: 100,
        validityDays: 30,
        totalIncome: 4500,
        image: 'silver.jpg'
    },
    {
        name: 'gold-boost',
        price: 3000,
        dailyIncome: 200,
        validityDays: 35,
        totalIncome: 7000,
        image: 'gold.jpg'
    },
    {
        name: 'platinum-power',
        price: 5000,
        dailyIncome: 400,
        validityDays: 40,
        totalIncome: 16000,
        image: 'platinum.jpg'
    },
    {
        name: 'diamond-elite',
        price: 10000,
        dailyIncome: 800,
        validityDays: 45,
        totalIncome: 36000,
        image: 'diamond.jpg'
    },
    {
        name: 'emerald-pro',
        price: 20000,
        dailyIncome: 1600,
        validityDays: 50,
        totalIncome: 80000,
        image: 'emerald.jpg'
    },
    {
        name: 'ruby-master',
        price: 40000,
        dailyIncome: 3200,
        validityDays: 55,
        totalIncome: 176000,
        image: 'ruby.jpg'
    },
    {
        name: 'sapphire-legend',
        price: 75000,
        dailyIncome: 5000,
        validityDays: 60,
        totalIncome: 300000,
        image: 'sapphire.jpg'
    }
];

async function seed() {
    await Package.deleteMany({}); // Clear existing packages
    await Package.insertMany(packages);
    console.log('Packages seeded successfully');
    mongoose.connection.close();
}

seed();