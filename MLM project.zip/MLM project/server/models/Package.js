const mongoose = require('mongoose');

const packageSchema = new mongoose.Schema({
    name: String,
    price: Number,
    dailyIncome: Number,
    validityDays: Number,
    totalIncome: Number,
    image: String
});

module.exports = mongoose.model('Package', packageSchema);