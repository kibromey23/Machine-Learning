const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new Schema({
//////////////////
//////////////acount section///////
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    referralCode: { type: String, unique: true },
    referredBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    package: { type: mongoose.Schema.Types.ObjectId, ref: 'Package' },
    todayIncome: { type: Number, default: 0 },
    referralCommissions: { type: Map, of: [{ amount: Number, date: Date }], default: {} },
    teamIncome: { type: Number, default: 0 }, // Total referral income
    totalIncome: { type: Number, default: 0 },
    totalWithdraw: { type: Number, default: 0 },
    currentBalance: { type: Number, default: 0 },
    isActive: { type: Boolean, default: true },
    //////////

    phone: { type: String, required: true },
   
    ref: { type: String, default: '' }, // Referral code used during signup
    referralLink: { type: String }, // Generated referral link
    isVerified: { type: Boolean, default: false },
    fname: { type: String },
    active: { type: Number, default: 1 },
    expiry: { type: Date },
    referralIncomeToday: { type: Number, default: 0 },
    totalReferralIncome: { type: Number, default: 0 },
    currentBalance: { type: Number, default: 0 },
    bankAccount: { type: String },
    withdrawPassword: { type: String },
    isAdmin: { type: Boolean, default: false },
    giftCode: { type: String },
    lastLogin: { type: Date },
    withdrawalHistory: [{
        amount: Number,
        method: String,
        date: Date,
        status: { type: String, enum: ['pending', 'completed'], default: 'pending' }
    }],
    referrals: {
        levelA: [{ type: Schema.Types.ObjectId, ref: 'User' }],
        levelB: [{ type: Schema.Types.ObjectId, ref: 'User' }],
        levelC: [{ type: Schema.Types.ObjectId, ref: 'User' }]
    },
    // Add fields from error message, made optional
    level: { type: Number, default: 0 },
    refereeId: { type: Schema.Types.ObjectId, ref: 'User', default: null },
    referrerId: { type: Schema.Types.ObjectId, ref: 'User', default: null }
});
const User = mongoose.model('User', userSchema);

const referralSchema = new Schema({
    phone: { type: String, required: true, unique: true },
    isVerified: { type: Boolean, default: false },
    referralCommissions: {
        levelA: { type: Number, default: 0 },
        levelB: { type: Number, default: 0 },
        levelC: { type: Number, default: 0 },
    },
    referrerId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    refereeId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    level: { type: String, enum: ['A', 'B', 'C'], required: true }
});

// Export both models
module.exports = {
    User: mongoose.model('User', userSchema),
    Referral: mongoose.model('Referral', referralSchema)
};