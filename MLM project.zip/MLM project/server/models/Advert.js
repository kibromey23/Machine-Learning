const mongoose = require('mongoose');
const advertSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    category: String,
    text: String,
    imageUrl: String,
    createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Advert', advertSchema);