const mongoose = require('mongoose');
const blogSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    title: String,
    category: String,
    details: String,
    imageUrl: String,
    postdate: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Blog', blogSchema);