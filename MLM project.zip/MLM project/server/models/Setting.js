const mongoose = require('mongoose');
const settingSchema = new mongoose.Schema({
    header: String,
    footer: String,
    blog_status: { type: Number, default: 1 },
    ads_status: { type: Number, default: 1 },
    airtime_status: { type: Number, default: 1 }
});
module.exports = mongoose.model('Setting', settingSchema);