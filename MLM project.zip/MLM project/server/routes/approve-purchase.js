router.post('/approve-purchase', auth, async (req, res) => {
    // Add admin check (e.g., req.user.isAdmin)
    const { requestId } = req.body;
    const purchaseRequest = await PurchaseRequest.findById(requestId);
    if (!purchaseRequest || purchaseRequest.status !== 'pending') {
        return res.status(400).json({ success: false, message: 'Invalid request' });
    }
    const user = await User.findById(purchaseRequest.userId);
    const pkg = await Package.findById(purchaseRequest.packageId);
    user.package = pkg._id;
    user.expiry = new Date(Date.now() + pkg.validityDays * 24 * 60 * 60 * 1000);
    purchaseRequest.status = 'approved';
    await Promise.all([user.save(), purchaseRequest.save()]);
    await new Payment({
        userId: user._id,
        amount: pkg.price,
        method: purchaseRequest.paymentMethod,
        date: new Date(),
        status: 'completed'
    }).save();
    res.json({ success: true, message: 'Purchase approved' });
});