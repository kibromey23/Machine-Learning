const express = require('express');
const Payment = require('../models/Payment');
const router = express.Router(); // Define router here
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { User, Referral } = require('../models/User');
const Package = require('../models/Package');
const cron = require('node-cron');
const auth = require('../middleware/auth');
const PurchaseRequest = require('../models/PurchaseRequest');
const WithdrawalRequest = require('../models/WithdrawalRequest');
const mongoose = require('mongoose');



const JWT_SECRET = process.env.JWT_SECRET || 'secret';
const ADMIN_CODE = process.env.ADMIN_CODE || 'makeMeAdmin';

const adminMiddleware = async (req, res, next) => {
    const user = await User.findById(req.user.id);
    if (!user || !user.isAdmin) {
        return res.status(403).json({ success: false, message: 'Admin access required' });
    }
    next();
};

const sendVerificationEmail = async (email, userId) => {
    console.log(`Verification email sent to ${email} with code for user ${userId}. Use code: 123456`);
    return { success: true };
};

const generateReferralCode = () => {
    return Math.random().toString(36).substring(2, 10).toUpperCase();
};

cron.schedule('0 0 * * *', async () => {
    try {
        const users = await User.find({ active: 1, package: { $ne: null }, isVerified: true }).populate('package');
        for (const user of users) {
            if (new Date() < user.expiry) {
                const dailyProfit = user.package.price * 0.08;
                user.todayIncome = dailyProfit;
                user.totalIncome += dailyProfit;
                user.currentBalance += dailyProfit;
                await user.save();
            }
        }
        console.log('Daily profit updated');
    } catch (err) {
        console.error('Cron error:', err.stack);
    }
});
///////////// signup ////////////////////////
router.post('/signup', async (req, res) => {
    const { username, email, phone, password, ref } = req.body;

    try {
        // Check if username or email already exists
        const existingUser = await User.findOne({ $or: [{ username }, { email }] });
        if (existingUser) {
            return res.status(400).json({ success: false, message: 'Username or email already exists' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const referralCode = generateReferralCode(); // Assuming this function exists
        const referralLink = `http://localhost:8080/index.html?ref=${referralCode}`;

        // Create new user with all required fields
        const user = new User({
            username,
            email,
            phone,
            password: hashedPassword,
            referralCode,
            referralLink,
            ref: ref || '',
            todayIncome: 0,
            teamIncome: 0, // Total referral income
            totalIncome: 0,
            totalWithdraw: 0,
            currentBalance: 0,
            isVerified: true // Skipping verification for testing
        });

        await user.save();
        console.log('New user saved:', user); // Debug: Check saved user

        // Generate JWT token
        const token = jwt.sign({ id: user._id, isAdmin: user.isAdmin }, JWT_SECRET, { expiresIn: '1h' });
        res.cookie('authToken', token, { 
            httpOnly: true, 
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 3600000 
        });

        // Response with all required fields
        res.json({
            success: true,
            message: 'Signup successful',
            _id: user._id,
            username: user.username,
            todayIncome: user.todayIncome,
            referralIncomeToday: 0, // No referrals yet
            totalReferralIncome: user.teamIncome,
            totalIncome: user.totalIncome,
            totalWithdraw: user.totalWithdraw,
            currentBalance: user.currentBalance,
            referralLink: user.referralLink
        });
    } catch (err) {
        console.error('Signup error:', err.stack);
        res.status(500).json({ success: false, message: 'Server error during signup' });
    }
});
//////////////////////////////
//login
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        console.log('Login request:', { username });
        if (!username || !password) {
            return res.status(400).json({ success: false, message: 'Username and password are required' });
        }
        const user = await User.findOne({ username });
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).json({ success: false, message: 'Wrong username or password' });
        }
        if (!user.isVerified) {
            return res.status(403).json({ success: false, message: 'Account not verified. Check your email/phone.' });
        }
        const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: '1h' });
        res.cookie('authToken', token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'strict',
            maxAge: 3600000
        });
        res.json({ success: true, message: 'Login successful', token });
    } catch (err) {
        console.error('Login error:', err.stack);
        res.status(500).json({ success: false, message: 'Server error during login' });
    }
});

router.get('/check-auth', auth, async (req, res) => {
    try {
        const user = await User.findById(req.user.id);
        res.json({ success: true, isAdmin: user.isAdmin });
    } catch (err) {
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

router.post('/logout', (req, res) => {
    console.log('Logout requested');
    res.clearCookie('authToken');
    res.json({ success: true });
});

//existing
router.post('/redeem-gift', auth, async (req, res) => {
    const { giftCode } = req.body;
    const user = await User.findById(req.user.id);
    if (user.giftCode === giftCode) {
        user.currentBalance += 100; // Example bonus
        user.giftCode = null;
        await user.save();
        res.json({ success: true, message: 'Gift redeemed' });
    } else {
        res.status(400).json({ success: false, message: 'Invalid gift code' });
    }
});
///////////profile getting///////////

router.get('/profile', auth, async (req, res) => {
    try {
        const user = await User.findById(req.user.id)
            .select('_id username todayIncome referralCommissions totalIncome totalWithdraw currentBalance package')
            .populate('package', 'name price dailyIncome validityDays');

        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        res.json({
            success: true,
            _id: user._id,
            username: user.username,
            todayIncome: user.todayIncome || 0,
            referralIncomeToday: user.referralCommissions || 0,
            totalReferralIncome: user.teamIncome || 0,
            totalIncome: user.totalIncome || 0,
            totalWithdraw: user.totalWithdraw || 0,
            currentBalance: user.currentBalance || 0,
            package: user.package ? {
                name: user.package.name,
                price: user.package.price,
                dailyIncome: user.package.dailyIncome,
                validityDays: user.package.validityDays
            } : null
        });
    } catch (err) {
        console.error('Profile fetch error:', err.stack);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});


////////////////////////////////

router.get('/packages', async (req, res) => {
    const packages = await Package.find();
    res.json({ success: true, packages });
});

router.post('/buy-package', auth, async (req, res) => {
    const { packageId, paymentMethod } = req.body;
    const pkg = await Package.findOne({ name: packageId });
    if (!pkg) return res.status(400).json({ success: false, message: 'Invalid package' });
    if (!['bank', 'wallet'].includes(paymentMethod)) {
        return res.status(400).json({ success: false, message: 'Invalid payment method' });
    }
    const user = await User.findById(req.user.id);
    user.package = pkg._id;
    user.expiry = new Date(Date.now() + pkg.validityDays * 24 * 60 * 60 * 1000);
    await user.save();
    await new Payment({
        userId: user._id,
        amount: pkg.price,
        method: paymentMethod,
        date: new Date(),
        status: 'pending'
    }).save();
    res.json({ success: true, message: `Package purchase initiated via ${paymentMethod}. Please complete the transfer.` });
});


///////////////////////////////////

router.post('/purchase-package', auth, async (req, res) => {
    const { packageId, paymentMethod } = req.body;

    // Input validation
    if (!packageId || !paymentMethod) {
        return res.status(400).json({ success: false, message: 'Missing packageId or paymentMethod' });
    }
    if (!mongoose.Types.ObjectId.isValid(packageId)) {
        return res.status(400).json({ success: false, message: 'Invalid packageId format' });
    }
    if (!['bank', 'wallet'].includes(paymentMethod)) {
        return res.status(400).json({ success: false, message: 'Invalid payment method. Use "bank" or "wallet"' });
    }

    try {
        // Fetch package
        const pkg = await Package.findById(packageId);
        if (!pkg) {
            return res.status(404).json({ success: false, message: 'Package not found' });
        }

        // Fetch user
        if (!req.user || !req.user.id) {
            return res.status(401).json({ success: false, message: 'User not authenticated' });
        }
        const user = await User.findById(req.user.id);
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        // Update user
        user.package = pkg._id;
        user.expiry = new Date(Date.now() + (pkg.validityDays || 0) * 24 * 60 * 60 * 1000);
        user.totalIncome = (user.totalIncome || 0) + (pkg.price * 0.08 || 0);
        user.currentBalance = (user.currentBalance || 0) + (pkg.price * 0.08 || 0);
        await user.save();

        // Record payment
        const payment = new Payment({
            userId: user._id,
            amount: pkg.price || 0,
            method: paymentMethod,
            date: new Date(),
            status: 'completed'
        });
        await payment.save();

        res.json({ success: true, message: 'Package purchased successfully' });
    } catch (err) {
        console.error('Purchase error:', err.stack); // Log full stack trace
        res.status(500).json({ success: false, message: `Server error: ${err.message}` });
    }
});
/////////////////////////////////////////////////////

router.post('/bank', auth, async (req, res) => {
    const { bankName, accountNumber } = req.body;
    const user = await User.findById(req.user.id);
    user.bankName = bankName;
    user.accountNumber = accountNumber;
    await user.save();
    res.json({ success: true, message: 'Bank details updated' });
});

router.post('/withdraw-password', auth, async (req, res) => {
    const { withdrawPassword } = req.body;
    const user = await User.findById(req.user.id);
    user.withdrawPassword = await bcrypt.hash(withdrawPassword, 10);
    await user.save();
    res.json({ success: true, message: 'Withdraw password set' });
});

router.post('/change-password', auth, async (req, res) => {
    const { oldPassword, newPassword, confirmNewPassword } = req.body;
    const user = await User.findById(req.user.id);
    const passwordMatch = await bcrypt.compare(oldPassword, user.password);
    if (!passwordMatch) return res.status(400).json({ success: false, message: 'Old password incorrect' });
    if (newPassword !== confirmNewPassword) return res.status(400).json({ success: false, message: 'New passwords do not match' });
    user.password = await bcrypt.hash(newPassword, 10);
    await user.save();
    const token = jwt.sign({ id: user._id, username: user.username }, JWT_SECRET, { expiresIn: '1h' });
    res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict', maxAge: 3600000 });
    res.json({ success: true, message: 'Password changed' });
});

router.get('/team', auth, async (req, res) => {
    const user = await User.findById(req.user.id);
    const team = await User.find({ ref: user.username });
    res.json({ success: true, team });
});
//////////////// request purchase ////////////
router.post('/request-purchase', auth, async (req, res) => {
    try {
        const { packageId, paymentMethod } = req.body;
        const pkg = await Package.findById(packageId);

        if (!pkg) {
            return res.status(404).json({ success: false, message: 'Package not found' });
        }

        // Store the purchase request for admin review
        const purchaseRequest = new PurchaseRequest({
            userId: req.user.id,
            packageId,
            paymentMethod,
            status: 'pending'
        });

        await purchaseRequest.save();
        res.json({ success: true, message: 'Purchase request submitted. Waiting for admin approval.' });
    } catch (err) {
        console.error('Purchase request error:', err);
        res.status(500).json({ success: false, message: 'Server error during purchase request' });
    }
});

////ADMIN

// Admin dashboard route

const path = require('path');
/*
router.get('/admin', auth, async (req, res) => {
    try {
        const user = await User.findById(req.user.id);
        if (!user || !user.isAdmin) {
            console.log('Redirecting non-admin to /index.html');
            return res.redirect('/index.html'); // Relative to localhost:3000
        }
        const adminPath = path.join(__dirname, '../views/admin.html');
        console.log('Serving admin.html from:', adminPath);
        res.sendFile(adminPath);
    } catch (err) {
        console.error('Admin route error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});
*/
router.get('/admin', (req, res) => {
    const adminPath = path.join(__dirname, '../views/admin.html');
    console.log('Attempting to serve:', adminPath);
    res.sendFile(adminPath, (err) => {
        if (err) {
            console.error('SendFile error:', err);
            res.status(404).json({ success: false, message: 'Admin page not found' });
        }
    });
});

// Add a test route to confirm api.js is working
router.get('/test', (req, res) => {
    res.json({ success: true, message: 'API is working' });
});
////

router.post('/admin/manage-purchase', auth, adminMiddleware, async (req, res) => {
    const { requestId, action } = req.body;
    const purchaseRequest = await PurchaseRequest.findById(requestId).populate('userId packageId');
    if (action === 'approve') {
        const user = purchaseRequest.userId;
        const pkg = purchaseRequest.packageId;
        user.package = pkg._id;
        user.expiry = new Date(Date.now() + pkg.validityDays * 24 * 60 * 60 * 1000);
        purchaseRequest.status = 'approved';
        await Promise.all([user.save(), purchaseRequest.save()]);
        await updateReferralCommissions(user, pkg.price);
        res.json({ success: true, message: 'Purchase approved' });
    } else {
        purchaseRequest.status = 'rejected';
        await purchaseRequest.save();
        res.json({ success: true, message: 'Purchase rejected' });
    }
});

async function updateReferralCommissions(user, packagePrice) {
    const referrerA = await User.findOne({ referralCode: user.ref });
    if (referrerA) {
        const commissionA = packagePrice * 0.30; // 30% Level A
        referrerA.referralCommissions.levelA += commissionA;
        referrerA.totalIncome += commissionA;
        referrerA.currentBalance += commissionA;
        await referrerA.save();
        await Referral.create({ referrerId: referrerA._id, refereeId: user._id, level: 'A' });

        const referrerB = await User.findOne({ referralCode: referrerA.ref });
        if (referrerB) {
            const commissionB = packagePrice * 0.10; // 10% Level B
            referrerB.referralCommissions.levelB += commissionB;
            referrerB.totalIncome += commissionB;
            referrerB.currentBalance += commissionB;
            await referrerB.save();
            await Referral.create({ referrerId: referrerB._id, refereeId: user._id, level: 'B' });

            const referrerC = await User.findOne({ referralCode: referrerB.ref });
            if (referrerC) {
                const commissionC = packagePrice * 0.05; // 5% Level C
                referrerC.referralCommissions.levelC += commissionC;
                referrerC.totalIncome += commissionC;
                referrerC.currentBalance += commissionC;
                await referrerC.save();
                await Referral.create({ referrerId: referrerC._id, refereeId: user._id, level: 'C' });
            }
        }
    }
}

router.get('/admin/overview', auth, adminMiddleware, async (req, res) => {
    const totalUsers = await User.countDocuments();
    const activeUsers = await User.countDocuments({ active: 1 });
    const totalSales = await Payment.aggregate([{ $match: { status: 'completed' } }, { $group: { _id: null, total: { $sum: '$amount' } } }]);
    const totalWithdrawals = await User.aggregate([{ $group: { _id: null, total: { $sum: '$totalWithdraw' } } }]);
    const totalReferralCommissions = await User.aggregate([{ $group: { _id: null, total: { $sum: '$teamIncome' } } }]);
    const pendingRequests = await PurchaseRequest.countDocuments({ status: 'pending' });
    res.json({
        success: true,
        overview: {
            totalUsers,
            activeUsers,
            totalSales: totalSales[0]?.total || 0,
            totalWithdrawals: totalWithdrawals[0]?.total || 0,
            totalReferralCommissions: totalReferralCommissions[0]?.total || 0,
            pendingApprovals: pendingRequests
        }
    });
});

router.get('/admin/users', auth, adminMiddleware, async (req, res) => {
    const { search = '', page = 1, limit = 10 } = req.query;
    const query = search ? { $or: [{ username: new RegExp(search, 'i') }, { email: new RegExp(search, 'i') }] } : {};
    const users = await User.find(query)
        .select('username email active referralCode totalIncome package')
        .populate('package', 'name price')
        .skip((page - 1) * limit)
        .limit(parseInt(limit));
    const total = await User.countDocuments(query);
    res.json({ success: true, users, total, pages: Math.ceil(total / limit) });
});

router.post('/admin/user/toggle-active', auth, adminMiddleware, async (req, res) => {
    const { userId } = req.body;
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    user.active = user.active === 1 ? 0 : 1;
    await user.save();
    res.json({ success: true, message: `User ${user.active === 1 ? 'activated' : 'deactivated'}` });
});

router.get('/admin/user/:id', auth, adminMiddleware, async (req, res) => {
    const user = await User.findById(req.params.id)
        .select('-password')
        .populate('package', 'name price');
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    const referrals = await User.find({ ref: user.username });
    const payments = await Payment.find({ userId: user._id });
    res.json({ success: true, user, referrals, payments });
});

router.get('/admin/referrals', auth, adminMiddleware, async (req, res) => {
    const totalReferrals = await User.countDocuments({ ref: { $ne: null } });
    const levelA = await User.aggregate([{ $match: { ref: { $ne: null } } }, { $group: { _id: '$ref', count: { $sum: 1 } } }]);
    res.json({ success: true, totalReferrals, levelA: levelA.length });
});


router.get('/admin/package-requests', auth, adminMiddleware, async (req, res) => {
    try {
        const requests = await PurchaseRequest.find({ status: 'pending' })
            .populate('userId', 'username')
            .populate('packageId', 'name price');
        res.json({ success: true, requests });
    } catch (err) {
        console.error('Package requests error:', err);
        res.status(500).json({ success: false, message: 'Server error' });
    }
});

router.post('/admin/packages', auth, adminMiddleware, async (req, res) => {
    const { name, price, dailyIncome, validityDays } = req.body;
    const pkg = new Package({ name, price, dailyIncome, validityDays });
    await pkg.save();
    res.json({ success: true, message: 'Package added', package: pkg });
});

router.get('/admin/transactions', auth, adminMiddleware, async (req, res) => {
    const deposits = await Payment.find({ status: 'completed' });
    const withdrawals = await User.find({ totalWithdraw: { $gt: 0 } }).select('username totalWithdraw');
    res.json({ success: true, deposits, withdrawals });
});

router.post('/admin/send-gift', auth, adminMiddleware, async (req, res) => {
    const { username, giftCode } = req.body;
    const user = await User.findOne({ username });
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    user.giftCode = giftCode;
    await user.save();
    res.json({ success: true, message: 'Gift code sent' });
});

// New Withdrawal Routes
router.post('/request-withdrawal', auth, async (req, res) => {
    const { amount, method, withdrawPassword } = req.body;
    const user = await User.findById(req.user.id);
    if (!user.withdrawPassword || !(await bcrypt.compare(withdrawPassword, user.withdrawPassword))) {
        return res.status(400).json({ success: false, message: 'Invalid withdrawal password' });
    }
    if (amount > user.balanceWallet) {
        return res.status(400).json({ success: false, message: 'Insufficient balance' });
    }
    const withdrawalRequest = new WithdrawalRequest({
        userId: user._id,
        amount,
        method
    });
    await withdrawalRequest.save();
    res.json({ success: true, message: 'Withdrawal request submitted, awaiting admin approval' });
});

router.get('/admin/withdrawal-requests', auth, adminMiddleware, async (req, res) => {
    const requests = await WithdrawalRequest.find({ status: 'pending' })
        .populate('userId', 'username');
    res.json({ success: true, requests });
});

router.post('/admin/manage-withdrawal', auth, adminMiddleware, async (req, res) => {
    const { requestId, action } = req.body;
    if (!['approve', 'reject'].includes(action)) {
        return res.status(400).json({ success: false, message: 'Invalid action' });
    }
    const withdrawalRequest = await WithdrawalRequest.findById(requestId);
    if (!withdrawalRequest || withdrawalRequest.status !== 'pending') {
        return res.status(400).json({ success: false, message: 'Invalid or already processed request' });
    }
    const user = await User.findById(withdrawalRequest.userId);
    if (action === 'approve') {
        if (user.balanceWallet < withdrawalRequest.amount) {
            return res.status(400).json({ success: false, message: 'Insufficient user balance' });
        }
        user.balanceWallet -= withdrawalRequest.amount;
        user.totalWithdraw += withdrawalRequest.amount;
        withdrawalRequest.status = 'approved';
        await Promise.all([user.save(), withdrawalRequest.save()]);
        res.json({ success: true, message: 'Withdrawal approved' });
    } else {
        withdrawalRequest.status = 'rejected';
        await withdrawalRequest.save();
        res.json({ success: true, message: 'Withdrawal rejected' });
    }
});

router.post('/admin/settings', auth, adminMiddleware, async (req, res) => {
    const { header, footer } = req.body;
    let settings = await Setting.findOne();
    if (!settings) settings = new Setting();
    settings.header = header;
    settings.footer = footer;
    await settings.save();
    res.json({ success: true, message: 'Settings updated' });
});

router.get('/admin/settings', auth, adminMiddleware, async (req, res) => {
    const settings = await Setting.findOne();
    res.json({ success: true, header: settings?.header, footer: settings?.footer });
});

//password resetting
const crypto = require('crypto');

router.post('/forgot-password', async (req, res) => {
    const { email } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    const resetToken = crypto.randomBytes(20).toString('hex');
    user.resetPasswordToken = resetToken;
    user.resetPasswordExpires = Date.now() + 3600000; // 1 hour
    await user.save();
    // Notify admin (pseudo-code; implement email service)
    await sendEmailToAdmin('Password Reset Request', `User ${user.username} requested a reset. Token: ${resetToken}`);
    res.json({ success: true, message: 'Reset request sent to admin' });
});

router.post('/admin/send-reset-link', auth, adminMiddleware, async (req, res) => {
    const { userId } = req.body;
    const user = await User.findById(userId);
    if (!user || !user.resetPasswordToken) return res.status(404).json({ success: false, message: 'Invalid request' });
    const resetLink = `http://localhost:8080/reset-password.html?token=${user.resetPasswordToken}`;
    // Send email (pseudo-code; implement email service)
    await sendEmail(user.email, 'Password Reset', `Click to reset: ${resetLink}`);
    res.json({ success: true, message: 'Reset link sent to user' });
});
router.post('/reset-password', async (req, res) => {
    const { token, newPassword } = req.body;
    const user = await User.findOne({
        resetPasswordToken: token,
        resetPasswordExpires: { $gt: Date.now() }
    });
    if (!user) return res.status(400).json({ success: false, message: 'Invalid or expired token' });
    user.password = await bcrypt.hash(newPassword, 10);
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();
    res.json({ success: true, message: 'Password reset successful' });
});
module.exports = router;